package com.kimo.controller

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.hardware.camera2.CameraManager
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.speech.RecognizerIntent
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.ContextCompat
import java.util.Locale

class MainActivity : ComponentActivity() {
    private lateinit var status: TextView
    private var torchOn = false

    private val speechLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == Activity.RESULT_OK) {
            val words = result.data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)
            words?.firstOrNull()?.let { runCommand(it) }
        } else {
            showStatus("आवाज़ समझ नहीं आई। फिर कोशिश करें।")
        }
    }

    private val cameraPermission = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (granted) toggleTorch() else showStatus("टॉर्च के लिए Camera permission चाहिए।")
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildScreen()
    }

    private fun buildScreen() {
        val scroll = ScrollView(this)
        val page = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(24, 36, 24, 28)
            setBackgroundColor(0xFF111827.toInt())
        }

        val logo = TextView(this).apply {
            text = "KIMO"
            textSize = 38f
            setTextColor(0xFFA78BFA.toInt())
            gravity = Gravity.CENTER
            typeface = android.graphics.Typeface.DEFAULT_BOLD
        }
        page.addView(logo, matchWrap())

        val subtitle = TextView(this).apply {
            text = "Your Android Voice + Touch Controller"
            textSize = 14f
            setTextColor(0xFFD1D5DB.toInt())
            gravity = Gravity.CENTER
            setPadding(0, 6, 0, 26)
        }
        page.addView(subtitle, matchWrap())

        val voice = makeButton("🎙  बोलकर कमांड दें") { startVoice() }
        page.addView(voice, matchWrap())

        status = TextView(this).apply {
            text = "नमस्ते! मैं Kimo हूँ। कोई कमांड बोलें या बटन दबाएँ।"
            textSize = 15f
            setTextColor(0xFFFFFFFF.toInt())
            gravity = Gravity.CENTER
            setPadding(12, 20, 12, 20)
        }
        page.addView(status, matchWrap())

        page.addView(makeButton("🔦  Flashlight ON / OFF") {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA)
                == PackageManager.PERMISSION_GRANTED) toggleTorch()
            else cameraPermission.launch(Manifest.permission.CAMERA)
        }, matchWrap())

        page.addView(makeButton("📶  Wi-Fi Settings") {
            openSettings(Settings.Panel.ACTION_WIFI)
        }, matchWrap())
        page.addView(makeButton("ᛒ  Bluetooth Settings") {
            openSettings(Settings.ACTION_BLUETOOTH_SETTINGS)
        }, matchWrap())
        page.addView(makeButton("⚙  Phone Settings") {
            openSettings(Settings.ACTION_SETTINGS)
        }, matchWrap())
        page.addView(makeButton("▶  Open YouTube") {
            openApp("com.google.android.youtube", "YouTube")
        }, matchWrap())
        page.addView(makeButton("🌐  Open Chrome") {
            openApp("com.android.chrome", "Chrome")
        }, matchWrap())
        page.addView(makeButton("💬  Open WhatsApp") {
            openApp("com.whatsapp", "WhatsApp")
        }, matchWrap())
        page.addView(makeButton("📞  Dial a number") {
            startActivity(Intent(Intent.ACTION_DIAL))
        }, matchWrap())
        page.addView(makeButton("✉  Compose SMS") {
            startActivity(Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:")))
        }, matchWrap())

        val note = TextView(this).apply {
            text = "सुरक्षा: Kimo संवेदनशील कामों के लिए Android की अपनी स्क्रीन खोलेगा। यह बिना अनुमति कॉल/SMS नहीं भेजता और दूसरे ऐप्स को जबरन बंद नहीं करता।"
            textSize = 12f
            setTextColor(0xFF9CA3AF.toInt())
            setPadding(4, 22, 4, 4)
        }
        page.addView(note, matchWrap())
        scroll.addView(page)
        setContentView(scroll)
    }

    private fun matchWrap() = LinearLayout.LayoutParams(
        LinearLayout.LayoutParams.MATCH_PARENT,
        LinearLayout.LayoutParams.WRAP_CONTENT
    ).apply { bottomMargin = 12 }

    private fun makeButton(label: String, action: () -> Unit) = Button(this).apply {
        text = label
        textSize = 15f
        isAllCaps = false
        setOnClickListener { action() }
    }

    private fun startVoice() {
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault())
            putExtra(RecognizerIntent.EXTRA_PROMPT, "Kimo को कमांड दें")
        }
        try { speechLauncher.launch(intent) }
        catch (_: Exception) { showStatus("इस फोन में Speech Recognition उपलब्ध नहीं है।") }
    }

    private fun runCommand(raw: String) {
        val command = raw.lowercase(Locale.ROOT)
        showStatus("आपने कहा: $raw")
        when {
            command.contains("torch") || command.contains("flash") || command.contains("टॉर्च") -> {
                if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA)
                    == PackageManager.PERMISSION_GRANTED) toggleTorch()
                else cameraPermission.launch(Manifest.permission.CAMERA)
            }
            command.contains("wifi") || command.contains("वाई फाई") ->
                openSettings(Settings.Panel.ACTION_WIFI)
            command.contains("bluetooth") || command.contains("ब्लूटूथ") ->
                openSettings(Settings.ACTION_BLUETOOTH_SETTINGS)
            command.contains("setting") || command.contains("सेटिंग") ->
                openSettings(Settings.ACTION_SETTINGS)
            command.contains("youtube") || command.contains("यूट्यूब") ->
                openApp("com.google.android.youtube", "YouTube")
            command.contains("chrome") || command.contains("क्रोम") ->
                openApp("com.android.chrome", "Chrome")
            command.contains("whatsapp") || command.contains("व्हाट्सएप") ->
                openApp("com.whatsapp", "WhatsApp")
            command.contains("call") || command.contains("कॉल") ->
                startActivity(Intent(Intent.ACTION_DIAL))
            command.contains("sms") || command.contains("message") || command.contains("मैसेज") ->
                startActivity(Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:")))
            else -> showStatus("यह कमांड अभी उपलब्ध नहीं है। Wi-Fi, Bluetooth, टॉर्च, Settings या ऐप खोलकर देखें।")
        }
    }

    private fun openSettings(action: String) {
        try { startActivity(Intent(action)) }
        catch (_: Exception) { showStatus("यह सेटिंग इस Android version पर उपलब्ध नहीं है।") }
    }

    private fun openApp(packageName: String, label: String) {
        val launch = packageManager.getLaunchIntentForPackage(packageName)
        if (launch != null) startActivity(launch)
        else showStatus("$label इस फोन में इंस्टॉल नहीं है।")
    }

    private fun toggleTorch() {
        try {
            val manager = getSystemService(CAMERA_SERVICE) as CameraManager
            val cameraId = manager.cameraIdList.firstOrNull {
                manager.getCameraCharacteristics(it)
                    .get(android.hardware.camera2.CameraCharacteristics.FLASH_INFO_AVAILABLE) == true
            }
            if (cameraId == null) { showStatus("इस फोन में Flashlight उपलब्ध नहीं है।"); return }
            torchOn = !torchOn
            manager.setTorchMode(cameraId, torchOn)
            showStatus(if (torchOn) "Flashlight चालू है।" else "Flashlight बंद है।")
        } catch (e: Exception) {
            torchOn = false
            showStatus("Flashlight कंट्रोल नहीं हो पाया: ${e.localizedMessage ?: "त्रुटि"}")
        }
    }

    private fun showStatus(message: String) {
        if (::status.isInitialized) status.text = message
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show()
    }
}
