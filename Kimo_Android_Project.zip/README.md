# Kimo Android Controller (starter)

## Included
- Android app named Kimo
- Voice input using Android speech recognition
- Touch buttons for flashlight, Wi-Fi panel, Bluetooth settings, phone settings
- Launch YouTube, Chrome and WhatsApp when installed
- Opens dialer and SMS composer (does not place/send automatically)

## Build
1. Open this folder in Android Studio.
2. Use JDK 17.
3. Allow Gradle sync and install Android SDK 35 if prompted.
4. Build > Build Bundle(s) / APK(s) > Build APK(s).

## Important limitations
- This is a starter command controller, not yet a general-purpose AI model.
- Android does not let ordinary apps silently toggle Wi-Fi/Bluetooth or force-close other apps on modern versions. Kimo opens the relevant system settings instead.
- Voice recognition may use the device's configured speech recognition service and may require internet.
- Flashlight permission is requested only when you use the flashlight.
- Calls and SMS open the system dialer/composer for user confirmation.
